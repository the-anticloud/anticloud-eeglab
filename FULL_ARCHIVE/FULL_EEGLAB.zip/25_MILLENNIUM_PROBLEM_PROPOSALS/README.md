# 25 Millennium Problem Proposals

**Project:** EEGLAB
**Upstream:** https://github.com/sccn/eeglab

Content specific to EEGLAB in category BRAIN_COMPUTER_INTERFACE.
